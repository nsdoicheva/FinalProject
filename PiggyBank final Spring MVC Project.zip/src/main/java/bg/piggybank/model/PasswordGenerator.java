package bg.piggybank.model;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class PasswordGenerator {

    private static final int PASSWORD_SIZE = 10;
	private static final int QUOTES_ASCII = 92;
	private static final int BACK_SLASH_ASCII = 47;
	private static final int FRONT_SLASH_ASCII = 34;
	private static final int COMMON_SYMBOLS_ASCCI_END_INTERVAL = 127;
	private static final int COMMON_SYMBOLS_ASCCI_START_INTERVAL = 33;
	private String str;
    private int randInt;
    private StringBuilder builder;
    private List<Integer> list;

    public PasswordGenerator() {
        this.list = new ArrayList<>();
        this.builder = new StringBuilder();
        buildPassword();
    }

    private void buildPassword() {

        //Add ASCII numbers of characters commonly acceptable in passwords
        for (int i = COMMON_SYMBOLS_ASCCI_START_INTERVAL; i < COMMON_SYMBOLS_ASCCI_END_INTERVAL; i++) {
            list.add(i);
        }

        //Remove characters /, \, and " as they're not commonly accepted
        list.remove(new Integer(FRONT_SLASH_ASCII));
        list.remove(new Integer(BACK_SLASH_ASCII));
        list.remove(new Integer(QUOTES_ASCII));

        /*Randomise over the ASCII numbers and append respective character
          values into a StringBuilder*/
        for (int i = 0; i < PASSWORD_SIZE; i++) {
            randInt = list.get(new SecureRandom().nextInt(QUOTES_ASCII-1));
            builder.append((char) randInt);
        }

        str = builder.toString();
    }

    public String generatePassword() {
        return str;
    }
}
