package bg.piggybank.model.accounts;

public enum CurrencyType {
	USD, GBP, EUR, BGN, RSD, RUB
}
