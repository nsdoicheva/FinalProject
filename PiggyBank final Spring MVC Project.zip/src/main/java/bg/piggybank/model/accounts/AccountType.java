package bg.piggybank.model.accounts;

public enum AccountType {
	РАЗПЛАЩАТЕЛНА, СПЕСТОВНА, КРЕДИТ
}
