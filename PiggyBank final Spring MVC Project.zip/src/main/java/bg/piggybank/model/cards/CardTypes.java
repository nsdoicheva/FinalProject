package bg.piggybank.model.cards;

public enum CardTypes {
	VISA, MASTERCARD, PIGGYCARD
}
