package bg.piggybank.model.exeptions;

public class FailedConnectionException extends Exception {

	private static final long serialVersionUID = -6278580661029352387L;

	protected FailedConnectionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected FailedConnectionException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	protected FailedConnectionException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public FailedConnectionException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
