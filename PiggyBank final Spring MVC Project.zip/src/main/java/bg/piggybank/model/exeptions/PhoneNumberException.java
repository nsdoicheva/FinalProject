package bg.piggybank.model.exeptions;

public class PhoneNumberException extends IncorrectContactInfoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5811543728570175016L;

	public PhoneNumberException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberException(String message, Exception cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PhoneNumberException(Exception cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
