/*------------------------------------*\
    SIMPLE LOGIN FORM
\*------------------------------------*/
document.addEventListener('DOMContentLoaded' , function(){
	
	var btnReg = document.getElementById('btn-reg');
	btnReg.addEventListener('click' , function(){
		location.replace("register.html");
		});
});